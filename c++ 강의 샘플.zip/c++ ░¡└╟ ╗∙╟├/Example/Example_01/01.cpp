#include <iostream>

int main()
{
    std::cout << "Hello World Example!\n";
    return 0;
}