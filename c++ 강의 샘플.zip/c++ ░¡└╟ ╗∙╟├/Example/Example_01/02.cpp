#include <iostream>
#include "../Example_Dll/framework.h"

#define _CRTDBG_MAP_ALLOC
#include <stdlib.h>
#include <crtdbg.h>
static int abc = 0;
int ss;
int main()
{
    _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
    char a[10];
    void* p = AllocMemory(10);
    //free(p);
    ((char*)p)[200] = 'a';
    int i;
    a[0] = 'a';
    std::cout << "&A:" << &a
        << "&p:" << &p
        << "*&p:" << (*&p)
        << "Hello World Example!\n";

    std::cin >> i;
}