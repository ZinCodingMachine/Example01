#include <iostream>
#include <iomanip>
static int abc[0x100];
static int def[0x200];
int ghi;

int main()
{
    size_t size1 = 0x9ABCDEF0;
    size_t size = 1024 * 1024 * 1024;
    char arr[1024];

    void* pointer;
    int integer;

    std::cout << "HEAP" << std::endl;
    for (int i = 0; i < 10; ++i)
    {
        pointer = malloc(size);
        std::cout << "pointer:" << pointer << std::endl;
    }
    arr[0] = 'a';

    std::cout << "STACK" << std::endl;
    std::cout
        << "&size1:" << &size1 << std::endl
        << "&size:" << &size << std::endl
        << "&arr[]:" << &arr << " size:0x" << std::hex << sizeof(arr) << std::endl
        << "&integer:" << &integer << std::endl
        << "&pointer:" << &pointer << std::endl;

    std::cout << "DATA" << std::endl;
    std::cout << "static abc:" << &abc << std::endl
        << "&def:" << &def << std::endl
        << "&ghi:" << &ghi << std::endl
        << "Hello World Example!" << std::endl;

    int in;
    std::cin >> in;
}