#include <iostream>
#include <thread>

static int abc = 0;
int ss;
void test()
{
    char a[1024 * 800];
    while (true)
        std::this_thread::sleep_for(std::chrono::seconds(1));
}
int main()
{
    char a[1024 * 512];
    void* p;

    int i;
    a[0] = 'a';
    for (int i = 0; i < 1500; i++)
    {
        std::thread thread1([]() {
            test();
            });
        thread1.detach();
    }


    std::cout << "&A:" << &a
        << "&p:" << &p
        << "static abc:" << &abc
        << "&ss:" << &ss
        << "Hello World Example!\n";

    std::cin >> i;
}