#include <iostream>
#include <thread>
#include "../Example_Dll/framework.h"

static int abc[0xff];
int ss;
void test()
{
    char a[1024 * 800];
    while (true)
        std::this_thread::sleep_for(std::chrono::seconds(1));
}
int main()
{
    char a[1024 * 512];
    void* p = malloc(1024 * 1024 * 100);
    void* pp = AllocMemory(1024 * 1024 * 100);
    int i;
    a[0] = 'a';

    std::cout << "&A:" << &a
        << "p:" << p
        << "pp:" << pp
        << "static abc:" << abc
        << "&ss:" << &ss
        << "Hello World Example!\n";

    std::cin >> i;
}