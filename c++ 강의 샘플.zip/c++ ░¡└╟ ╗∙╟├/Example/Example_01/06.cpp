#include <iostream>
#include <wtypes.h>
#include <tchar.h>
#include <DbgHelp.h>
#include <thread>
#include <format>
#pragma comment ( lib, "DbgHelp" )

BOOL CreateMinidump(MINIDUMP_EXCEPTION_INFORMATION& dmpInfo)
{
    auto t = std::time(nullptr);
    std::tm now;
    localtime_s(&now, &t);

    const auto& aumpPath = std::format(_T("{:02d}-{:02d}-{:02d} {:02d}_{:02d}_{:02d}.dmp"),
        now.tm_year + 1900,
        now.tm_mon + 1,
        now.tm_mday,
        now.tm_hour,
        now.tm_min,
        now.tm_sec);

    auto hFile = CreateFile(aumpPath.c_str(), GENERIC_WRITE, FILE_SHARE_WRITE, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    if (INVALID_HANDLE_VALUE == hFile)
    {
        return EXCEPTION_CONTINUE_SEARCH;
    }
    // ���� ����
    auto result = ::MiniDumpWriteDump(::GetCurrentProcess(), ::GetCurrentProcessId(), hFile, MiniDumpNormal, &dmpInfo, NULL, NULL);
    CloseHandle(hFile);
    return result;

}
// ����
LONG CALLBACK TopLevelExceptionFilterCallBack(EXCEPTION_POINTERS* exceptionInfo)
{
    MINIDUMP_EXCEPTION_INFORMATION dmpInfo = { 0 };
    dmpInfo.ThreadId = ::GetCurrentThreadId(); // Threae ID
    dmpInfo.ExceptionPointers = exceptionInfo; // Exception Info
    dmpInfo.ClientPointers = FALSE;
    /*
    if (exceptionInfo->ExceptionRecord->ExceptionCode == EXCEPTION_STACK_OVERFLOW)
    {
        std::thread t([&]{
            CreateMinidump(dmpInfo);
        });
        t.join();
        return EXCEPTION_EXECUTE_HANDLER;
    }
    */
    return (TRUE == CreateMinidump(dmpInfo)) ? EXCEPTION_EXECUTE_HANDLER : EXCEPTION_CONTINUE_SEARCH;
}
static int abc[20];
int ss[20];

void test(int a)
{
    int b[1024 * 512];
    std::cout << "&b[]:" << &b << std::endl;
    test(b[0]);
}
int main()
{
    // Exception �ݹ��� ������ش�.
    SetUnhandledExceptionFilter(TopLevelExceptionFilterCallBack);

    {
        char arr[1024 * 512];
        size_t size1 = 0x9ABCDEF0;
        size_t size = 0x12345678;
        void* pointer;
        int integer;

        for (int i = 0; i < 10; ++i)
        {
            pointer = malloc(size);
            ((char*)pointer)[0] = 'a';
        }

        arr[0] = 'a';
        test(0);
        std::cout << "&arr[]:" << &arr << std::endl
            << "&size:" << &size << std::endl
            << "&pointer:" << &pointer << std::endl
            << "&integer:" << &integer << std::endl
            << "static abc:" << &abc << std::endl
            << "&ss:" << &ss << std::endl
            << "Hello World Example!" << std::endl;

        int in;
        std::cin >> in;
    }

}