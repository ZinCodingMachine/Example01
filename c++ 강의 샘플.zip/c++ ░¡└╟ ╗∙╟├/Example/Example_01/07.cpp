#include <iostream>
#include <iomanip>

class MyClass
{
    char m_array[1024 * 1024 * (512 + 0)];
public:
    /*
    static void* operator new(size_t stAllocateBlock, char chInit)
    {
        return ::operator new(stAllocateBlock);
    }
    static void* operator new(size_t stAllocateBlock, void* Where)
    {
        return ::operator new(stAllocateBlock, Where);
    }*/

    MyClass()
    {
        std::cout << __FUNCTION__ << " this:" << this << std::endl;
    }

    ~MyClass()
    {
        std::cout << __FUNCTION__ << " this:" << this << std::endl;
    }
    //virtual void test() {}
};
void OutOfHeapMemory()
{
    std::cerr << __FUNCTION__;
    std::abort();
}

void* operator new(std::size_t sz)
{
    std::printf("global op new called, size = %zu\n", sz);
    if (sz == 0)
        ++sz; // avoid std::malloc(0) which may return nullptr on success

    if (void* ptr = std::malloc(sz))
        return ptr;

    throw std::bad_alloc{}; // required by [new.delete.single]/3
}
void* operator new(std::size_t sz, const char* file, int line, bool b)
{
    std::printf("global op new called, size = %zu\n", sz);
    if (sz == 0)
        ++sz; // avoid std::malloc(0) which may return nullptr on success

    if (void* ptr = std::malloc(sz))
        return ptr;

    throw std::bad_alloc{}; // required by [new.delete.single]/3
}
void* operator new[](std::size_t count)
{
    return ::operator new[](count);
}

void operator delete(void* ptr) noexcept
{
    std::puts("global op delete called");
    std::free(ptr);
}
void operator delete[](void* _Block, size_t _Size) noexcept
{
    ::operator delete[](_Block, _Size);
}
int main()
{
    {
        //std::set_new_handler(OutOfHeapMemory);
        auto pTest2 = malloc(sizeof(MyClass));
        auto pTest3 = new (pTest2) MyClass();
        auto pTest4 = new(__FILE__, __LINE__, true) MyClass();
        auto pTest = new (std::nothrow)  MyClass;
        delete pTest3;
    }
    {
        auto pTest1 = new MyClass();
        auto pTest = new MyClass[2];
        delete[] pTest;
    }

    int i;
    std::cin >> i;
}