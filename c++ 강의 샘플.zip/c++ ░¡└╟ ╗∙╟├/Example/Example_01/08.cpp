#include <iostream>
#include <list>

#define _CRTDBG_MAP_ALLOC
#include <stdlib.h>
#include <crtdbg.h>

class MyClass
{
    char* m_array;
public:
    MyClass() : m_array(new char[1024])
    {
        m_array[0] = (char)((int)this & 0xff);
        std::cout << __FUNCSIG__ << " this:" << this << " m_array:" << (void*)m_array << std::endl;
    }

    ~MyClass()
    {
        std::cout << __FUNCSIG__ << " this:" << this << " m_array:" << (void*)m_array << std::endl;

        delete[] m_array;
    }

    MyClass(const MyClass& a) : m_array(new char[1024])
    {
        memcpy(m_array, a.m_array, sizeof(m_array));
        std::cout << __FUNCSIG__ << " this:" << this << " from:" << &a << std::endl;
    }

    MyClass(MyClass&& a) :m_array(std::move(a.m_array))
    {
        a.m_array = nullptr;
        std::cout << __FUNCSIG__ << " this:" << this << " from:" << &a << std::endl;
    }

    MyClass& operator=(MyClass&& other) noexcept
    {
        m_array = std::move(other.m_array);
        other.m_array = nullptr;
        return *this;
    }

    static void Swap(MyClass& a, MyClass& b)
    {
        std::cout << __FUNCSIG__ << std::endl;
        std::cout << "before" << std::endl;
        std::cout << " a:" << &a << " m_array:" << (int)a.m_array[0] << std::endl;
        std::cout << " b:" << &b << " m_array:" << (int)b.m_array[0] << std::endl;

        MyClass t = std::move(a);
        a = std::move(b);
        b = std::move(t);

        std::cout << "after" << std::endl;
        std::cout << " a:" << &a << " m_array:" << (int)a.m_array[0] << std::endl;
        std::cout << " b:" << &b << " m_array:" << (int)b.m_array[0] << std::endl;
    }
};
void Test(MyClass&& a)
{
    std::cout << __FUNCSIG__ << " a:" << &a << std::endl;
}
int main()
{
    _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);

    /* {
         MyClass a;
         Test(std::move(a));
     }*/

    {
        MyClass a, b;
        MyClass::Swap(a, b);
    }
}