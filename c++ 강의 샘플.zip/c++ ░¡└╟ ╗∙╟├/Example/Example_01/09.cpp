#include <iostream>

struct Vec2
{
	float x;
	float y;

	Vec2() : x(0.f), y(0.f)
	{
		std::cout << __FUNCSIG__ << " this:" << this << std::endl;
	}

	Vec2(float x, float y) : x(x), y(y)
	{
		std::cout << __FUNCSIG__ << " this:" << this << std::endl;
	}

	~Vec2()
	{
		std::cout << __FUNCSIG__ << " this:" << this << std::endl;
	}

	Vec2 operator+(const Vec2& other)
	{
		std::cout << __FUNCSIG__ << " this:" << this << std::endl;
		return Vec2(x + other.x, y + other.y);
	}
};
struct Vec3
{
	float x;
	float y;
	float z;

	Vec3() : x(0.f), y(0.f), z(0.f)
	{
		std::cout << __FUNCSIG__ << " this:" << this << std::endl;
	}

	Vec3(float x, float y, float z) : x(0.f), y(0.f), z(z)
	{
		std::cout << __FUNCSIG__ << " this:" << this << std::endl;
	}

	~Vec3()
	{
		std::cout << __FUNCSIG__ << " this:" << this << std::endl;
	}

	Vec3 operator+(const Vec3& other)
	{
		std::cout << __FUNCSIG__ << " this:" << this << std::endl;
		return Vec3(x + other.x, y + other.y, z + other.z);
	}

	Vec3 operator+(const Vec2& other)
	{
		std::cout << __FUNCSIG__ << " this:" << this << std::endl;
		return Vec3(x + other.x, y + other.y, z);
	}

	friend Vec3 operator+(const Vec2& a, const Vec3& b)
	{
		return Vec3(a.x + b.x, a.y + b.y, b.z);
	}
};


int main()
{
	Vec2 v2A(1, 2), v2B(2, 4);
	auto v2C = v2A + v2B;

	Vec3 v3A(1, 2, 3), v3B(3, 6, 9);
	auto v3C = v3A + v3B;
	auto v3D = v3A + v2A;
	auto v3E = v2A + v3A;
	return 0;
}