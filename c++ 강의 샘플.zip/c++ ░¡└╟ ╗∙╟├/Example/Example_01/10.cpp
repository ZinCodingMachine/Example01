#include <iostream>
#include <list>

#define _CRTDBG_MAP_ALLOC
#include <stdlib.h>
#include <crtdbg.h>

class MyClass
{
    char* m_array;
private:
    MyClass() : m_array(new char[1024])
    {
        m_array[0] = (char)((int)this & 0xff);
        std::cout << __FUNCSIG__ << " this:" << this << " m_array:" << (void*)m_array << std::endl;
    }

    MyClass(const MyClass&) = default;
public:
    static MyClass& GetInstance()
    {
        static MyClass _this;
        return _this;
    }

    ~MyClass()
    {
        std::cout << __FUNCSIG__ << " this:" << this << " m_array:" << (void*)m_array << std::endl;

        delete[] m_array;
    }
};
int main()
{
    MyClass& a = MyClass::GetInstance();
    MyClass b = MyClass::GetInstance();

    {
        MyClass a;                          // error
        MyClass* p = new MyClass(); // error
    }
}