#include <iostream>
#include <vector>
#include <array>
#include <list>
#include <deque>
#include <map>
#include <unordered_map>
#include <iterator>
#include <algorithm>

#define _CRTDBG_MAP_ALLOC
#include <stdlib.h>
#include <crtdbg.h>

class MyClass
{
    char m_array[1024];
public:
    MyClass() = delete;
    MyClass(char a)
    {
        m_array[0] = a;
        std::cout << __FUNCSIG__ << " this:" << this << " m_array[0]:" << (int)m_array[0] << std::endl;
    }
    MyClass(const  MyClass& a)
    {
        memcpy(m_array, a.m_array, sizeof(m_array));
        std::cout << __FUNCSIG__ << " this:" << this << " from:" << &a << std::endl;
    }
    MyClass(MyClass&& a)
    {
        memcpy(m_array, a.m_array, sizeof(m_array));
        std::cout << __FUNCSIG__ << " this:" << this << " from:" << &a << std::endl;
    }
    ~MyClass()
    {
        std::cout << __FUNCSIG__ << " this:" << this << " m_array[0]:" << (int)m_array[0] << std::endl;
    }
    MyClass& operator=(const MyClass&) = default;
    void test() {}
};
void* operator new(std::size_t sz)
{
    if (sz == 0)
        ++sz; // avoid std::malloc(0) which may return nullptr on success

    if (void* ptr = std::malloc(sz))
    {
        std::cout << __FUNCSIG__ << " ptr:" << ptr << " sz:" << sz << std::endl;
        return ptr;
    }

    throw std::bad_alloc{}; // required by [new.delete.single]/3
}
void* operator new[](std::size_t count)
{
    if (count == 0)
        ++count; // avoid std::malloc(0) which may return nullptr on success

    if (void* ptr = std::malloc(count))
    {
        std::cout << __FUNCSIG__ << " ptr:" << ptr << " sz:" << count << std::endl;
        return ptr;
    }

    throw std::bad_alloc{}; // required by [new.delete.single]/3
}
int main()
{
    _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
    /*{
        std::istream_iterator<int> it;
        std::istream_iterator<int> it_end;
        for (it = std::cin; it != it_end; ++it)
            std::cout << *it << std::endl;
    }*/
    /*{
        std::string arr[]{"abc", "def", "ghi" };
        std::ostream_iterator<std::string> it = std::cout;
        for (auto& e : arr)
        {
            *it = e;
            --it;
        }
    }*/
    /*{
        std::array<MyClass, 1> arr;
        auto it = arr.begin();

        it--;
        ++it;
        it += 2;
        auto b = it < (it + 1);
    }*/

    //{
    //    std::vector<MyClass> vec;
    //    for (int i = 0; i < 2; ++i)
    //        vec.push_back(MyClass(i));

    //    // ������ ����
    //    for (auto& e : vec)
    //    {
    //        e.test();
    //    }

    //    // ������ �ݺ���
    //    for (auto it = vec.begin(); it != vec.end(); ++it)
    //    {
    //        (*it).test();
    //        it->test();
    //    }

    //    // ������ �ݺ���
    //    for (auto it = vec.rbegin(); it != vec.rend(); ++it)
    //    {
    //        (*it).test();
    //        it->test();
    //    }

    //    // ���� ������
    //    vec[0].test();

    //    // �����
    //    vec.pop_back();
    //    vec.erase(vec.begin());
    //    vec.clear();
    //}

    /*{
        std::vector<MyClass> vec;
        vec.reserve(2);
        for (int i = 0; i < 2; ++i)
            vec.push_back(MyClass(i));
    }*/

    /*{
        std::deque<MyClass> deq;
        for (int i = 0; i < 9; ++i)
            deq.push_back(MyClass(i));
    }*/

    /*{
        std::list<MyClass> list;
        for (int i = 0; i < 5; ++i)
            list.push_back(MyClass(i));
    }*/

    /*{
        struct less
        {
            constexpr bool operator()(const int& _Left, const int& _Right) const {
                return _Left < _Right;
            }
        };
        std::map<int, MyClass, less> map;
        for (int i = 0; i < 100; ++i)
            map.insert({ i, MyClass(i) });
    }*/

    /*{
        struct bypassHash {
            size_t operator()(int v) const {
                std::cout << __FUNCSIG__ << " v:" << v << std::endl;
                return (size_t)0;
            }
        };

        struct MyEqual_to {
            bool operator()(const int _Keyval1, const int _Keyval2) const {
                std::cout << __FUNCSIG__ << " _Keyval1:" << _Keyval1 << " _Keyval2:" << _Keyval2 << std::endl;
                return _Keyval1 == _Keyval2;
            }
        };

        std::unordered_map<int, MyClass, bypassHash, MyEqual_to> map;
        map.reserve(10);

        for (int i = 0; i < 10; ++i)
            map.insert({ i, MyClass(i) });

        std::cout << "find:" << std::endl;
        auto it = map.find(9);
        std::cout << "bucket_size:" << map.bucket_size(map.bucket(9)) << std::endl;
    }*/

    {
        // ���� ���� ���¿��� ��
        std::array<int, 3> arr = { 10,15,30 };
        std::cout << "10 upper_bound �ʰ��ϴ� ���� �� : " << *upper_bound(arr.begin(), arr.end(), 35) << std::endl;
        std::cout << "10 lower_bound �̻��� ���� �� : " << *lower_bound(arr.begin(), arr.end(), 10) << std::endl;
        std::cout << "11 upper_bound �ʰ��ϴ� ���� �� : " << *upper_bound(arr.begin(), arr.end(), 11) << std::endl;
        std::cout << "11 lower_bound �̻��� ���� �� : " << *lower_bound(arr.begin(), arr.end(), 11) << std::endl;
    }
    /*{
        std::map<int, char> map = { {69, 'F'}, {79, 'C'}, {89, 'B'}, {100, 'A'} };
        while (true)
        {
            int score = 0;
            std::cin >> score;
            if (score < 0 || score > 100)
            {
                std::cout << "���� ����(0~100)" << std::endl;
                continue;
            }

            std::cout << "���� : " << score << " ����:" << map.lower_bound(score)->second << std::endl;
        }
    }*/
}