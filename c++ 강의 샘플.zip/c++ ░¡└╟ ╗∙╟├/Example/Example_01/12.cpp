#include <iostream>
#include <vector>
#include <array>
#include <list>
#include <deque>
#include <map>
#include <unordered_map>
#include <iterator>
#include <algorithm>
#include <thread>
#include <sstream>
#include <mutex>
#include <chrono>
#define _CRTDBG_MAP_ALLOC
#include <stdlib.h>
#include <crtdbg.h>

class MyClass
{
    char m_array[1024];
public:
    MyClass() = delete;
    MyClass(char a)
    {
        m_array[0] = a;
        std::cout << __FUNCSIG__ << " this:" << this << " m_array[0]:" << (int)m_array[0] << std::endl;
    }
    MyClass(const  MyClass& a)
    {
        memcpy(m_array, a.m_array, sizeof(m_array));
        std::cout << __FUNCSIG__ << " this:" << this << " from:" << &a << std::endl;
    }
    MyClass(MyClass&& a)
    {
        memcpy(m_array, a.m_array, sizeof(m_array));
        std::cout << __FUNCSIG__ << " this:" << this << " from:" << &a << std::endl;
    }
    ~MyClass()
    {
        std::cout << __FUNCSIG__ << " this:" << this << " m_array[0]:" << (int)m_array[0] << std::endl;
    }
    MyClass& operator=(const MyClass&) = default;
    void test() {}
};
//void* operator new(std::size_t sz)
//{
//    if (sz == 0)
//        ++sz; // avoid std::malloc(0) which may return nullptr on success
//
//    if (void* ptr = std::malloc(sz))
//    {
//        std::cout <<  __FUNCSIG__ << " ptr:" << ptr << " sz:" << sz << std::endl;
//        return ptr;
//    }
//
//    throw std::bad_alloc{}; // required by [new.delete.single]/3
//}
//void* operator new[](std::size_t count)
//{
//    if (count == 0)
//        ++count; // avoid std::malloc(0) which may return nullptr on success
//
//    if (void* ptr = std::malloc(count))
//    {
//        std::cout << __FUNCSIG__ << " ptr:" << ptr << " sz:" << count << std::endl;
//        return ptr;
//    }
//
//    throw std::bad_alloc{}; // required by [new.delete.single]/3
//}


int main()
{
    _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);

    /*{
        thread_local int abc[1024 * 1024];
        for (int i = 0; i < 10; ++i)
        {
            std::thread t1([&]() {

                std::stringstream ss;
                ss << "thread id:" << std::this_thread::get_id() << " abc:" << &abc << std::endl;
                std::cout << ss.str();

                while (true)
                    std::this_thread::sleep_for(std::chrono::seconds(1));
                });
            t1.detach();
        }

        int i;
        std::cin >> i;

        for (int i = 0; i < 10; ++i)
        {
            std::thread t1([]() {

                std::stringstream ss;
                ss << "thread id:" << std::this_thread::get_id() << std::endl;
                std::cout << ss.str();

                    std::this_thread::sleep_for(std::chrono::seconds(5));
                });
            t1.detach();
        }
    }*/

    /*{
        std::mutex gMutex;
        int total = 0;
        for (int i = 0; i < 10; ++i)
        {
            std::thread t1([&]() {
                for (int i = 0; i < 10000; ++i)
                {
                    gMutex.lock();
                    ++total;
                    gMutex.unlock();
                }

                std::stringstream ss;
                ss << "thread id:" << std::this_thread::get_id() << std::endl;
                std::cout << ss.str();
            });

            t1.detach();
        }

        while (true)
        {
            int i;
            std::cin >> i;

            std::cout << "total:" << total << std::endl;
        }
    }*/

    {
        std::atomic<int> total = 0;
        for (int i = 0; i < 10; ++i)
        {
            std::thread t1([&]() {
                auto startTime = std::chrono::system_clock::now();
                for (int i = 0; i < 10000000; ++i)
                    ++total;

                auto endTime = std::chrono::system_clock::now();
                auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(endTime - startTime);
                std::stringstream ss;
                ss << "thread id:" << std::this_thread::get_id() << std::endl;
                ss << "duration:" << duration.count() << std::endl;
                std::cout << ss.str();
                });

            t1.detach();
        }

        while (true)
        {
            int i;
            std::cin >> i;

            std::cout << "total:" << total << std::endl;
        }
    }
    //{
    //    while (true)
    //    {
    //        int count;
    //        std::cin >> count;

    //        std::condition_variable cv;
    //        std::mutex gMutex;
    //        std::atomic<int> finishedCount = 0;

    //        const int workers = 5;
    //        std::atomic<long long> total = 0;
    //        auto divCount = count / workers;
    //        for (int w = 0; w < workers; ++w)
    //        {
    //            std::thread t1([&](int s, int e) {
    //                auto startTime = std::chrono::system_clock::now();
    //                long long t = 0;
    //                for (auto i = s; i <= e; ++i)
    //                    t += i;

    //                total += t;

    //                auto endTime = std::chrono::system_clock::now();
    //                auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(endTime - startTime);
    //                std::stringstream ss;
    //                ss << "thread id:" << std::this_thread::get_id() << std::endl;
    //                ss << "sum(" << s << ", " << e << ") = " << t << std::endl;
    //                ss << "duration:" << duration.count() << std::endl;
    //                std::cout << ss.str();

    //                // �ϷḦ �˸�
    //                finishedCount++;
    //                cv.notify_one();
    //            }, w * divCount + 1, divCount * (w + 1));

    //            t1.detach();
    //        }

    //        auto startTime = std::chrono::system_clock::now();
    //        std::unique_lock autoLock(gMutex);
    //        cv.wait(autoLock, [&] {return finishedCount == workers; });

    //        auto endTime = std::chrono::system_clock::now();
    //        auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(endTime - startTime);
    //        std::cout << "It's done." << std::endl;
    //        std::cout << "sum(" << 1 << ", " << count << ") = " << total << std::endl;
    //        std::cout << "duration:" << duration.count() << std::endl;
    //    }
    //}
    /*{
        std::mutex gMutex;
        int total = 0;
        for (int i = 0; i < 10; ++i)
        {
            std::thread t1([&]() {
                for (int i = 0; i < 10000; ++i)
                {
                    std::lock_guard<std::mutex> autoLock(gMutex);
                    ++total;
                }

                std::stringstream ss;
                ss << "thread id:" << std::this_thread::get_id() << std::endl;
                std::cout << ss.str();
            });

            t1.detach();
        }

        while (true)
        {
            int i;
            std::cin >> i;

            std::cout << "total:" << total << std::endl;
        }
    }*/

    /*{
        std::mutex gMutex1;
        std::mutex gMutex2;
        int total = 0;
        {
            std::thread t1([&]() {
                for (int i = 0; i < 10000; )
                {
                    {
                        std::unique_lock<std::mutex> autoLock1(gMutex1);
                        std::unique_lock<std::mutex> autoLock2(gMutex2);

                        ++total;
                    }

                    ++i;
                }

                std::stringstream ss;
                ss << "thread id:" << std::this_thread::get_id() << std::endl;
                std::cout << ss.str();
             });

            t1.detach();
        }
        {
            std::thread t1([&]() {
                for (int i = 0; i < 10000;)
                {
                    {
                        std::unique_lock<std::mutex> autoLock1(gMutex2);
                        std::unique_lock<std::mutex> autoLock2(gMutex1);

                        ++total;
                    }

                    ++i;
                }

                std::stringstream ss;
                ss << "thread id:" << std::this_thread::get_id() << std::endl;
                std::cout << ss.str();
            });

            t1.detach();
        }

        while (true)
        {
            int i;
            std::cin >> i;

            std::cout << "total:" << total << std::endl;
        }
    }*/
    /*{
        std::mutex gMutex1;
        std::mutex gMutex2;
        int total = 0;
        {
            std::thread t1([&]() {
                for (int i = 0; i < 10000; )
                {
                    {
                        std::unique_lock<std::mutex> autoLock1(gMutex1, std::defer_lock);
                        std::unique_lock<std::mutex> autoLock2(gMutex2, std::defer_lock);

                        if (!autoLock1.try_lock())
                            continue;

                        if (!autoLock2.try_lock())
                            continue;

                        ++total;
                    }

                    ++i;
                }

                std::stringstream ss;
                ss << "thread id:" << std::this_thread::get_id() << std::endl;
                std::cout << ss.str();
             });

            t1.detach();
        }
        {
            std::thread t1([&]() {
                for (int i = 0; i < 10000;)
                {
                    {
                        std::unique_lock<std::mutex> autoLock1(gMutex2, std::defer_lock);
                        std::unique_lock<std::mutex> autoLock2(gMutex1, std::defer_lock);

                        if (!autoLock1.try_lock())
                            continue;

                        if (!autoLock2.try_lock())
                            continue;

                        ++total;
                    }

                    ++i;
                }

                std::stringstream ss;
                ss << "thread id:" << std::this_thread::get_id() << std::endl;
                std::cout << ss.str();
            });

            t1.detach();
        }

        while (true)
        {
            int i;
            std::cin >> i;

            std::cout << "total:" << total << std::endl;
        }
    }*/

    //{
    //    std::deque<std::pair<int/*start*/, int/*end*/>> deq;
    //    std::condition_variable cv;
    //    std::mutex gMutex;
    //    const int workers = 5;
    //    {
    //        for (int w = 0; w < workers; ++w)
    //        {
    //            std::thread t1([&]() {

    //                while (true)
    //                {
    //                    decltype(deq)::value_type job;
    //                    // �̺�Ʈ�� ���⸦ ��ٸ�
    //                    {
    //                        std::unique_lock<std::mutex> autoLock(gMutex);
    //                        cv.wait(autoLock, [&]() {return !deq.empty(); });
    //                        job = deq.front();
    //                        deq.pop_front();
    //                    }

    //                    // �̺�Ʈ�� �Դٸ� ����Ǵ� �ڵ�
    //                    auto startTime = std::chrono::system_clock::now();
    //                    long long total = 0;
    //                    for (int w = job.first; w <= job.second; ++w)
    //                        total += w;

    //                    auto endTime = std::chrono::system_clock::now();
    //                    auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(endTime - startTime);
    //                    std::stringstream ss;
    //                    ss << "thread id:" << std::this_thread::get_id() << " gMutex:" << gMutex.native_handle() << std::endl;
    //                    ss << "sum(" << job.first << ", " << job.second << ") = " << total << std::endl;
    //                    ss << "duration:" << duration.count() << std::endl;
    //                    std::cout << ss.str();
    //                }
    //                });
    //            t1.detach();
    //        }
    //    }

    //    while (true)
    //    {
    //        int i;
    //        int count;
    //        std::cin >> i >> count;

    //        switch (i)
    //        {
    //        case 0:
    //        {
    //            // ���� ���� �����ؼ� ��Ŀ���� ����
    //            auto divCount = count / workers;
    //            for (int w = 0; w < workers; ++w)
    //            {
    //                std::unique_lock<std::mutex> autoLock(gMutex);
    //                deq.push_back(std::make_pair(w * divCount + 1, divCount * (w + 1)));
    //            }
    //            cv.notify_all();
    //        }break;
    //        case 1:
    //        {
    //            std::unique_lock<std::mutex> autoLock(gMutex);
    //            deq.push_back(std::make_pair(1, count));
    //            cv.notify_one();
    //        }break;
    //        }
    //    }
    //}

    int i;
    std::cin >> i;
}