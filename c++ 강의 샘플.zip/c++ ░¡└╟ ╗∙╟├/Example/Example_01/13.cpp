#include <iostream>
#include <vector>
#include <array>
#include <list>
#include <deque>
#include <map>
#include <unordered_map>
#include <iterator>
#include <algorithm>
#include <thread>
#include <sstream>
#include <mutex>
#include <chrono>
#define _CRTDBG_MAP_ALLOC
#include <stdlib.h>
#include <crtdbg.h>
#include <future>

class MyClass
{
    char m_array[1024];
public:
    MyClass() = delete;
    MyClass(char a)
    {
        m_array[0] = a;
        std::cout << __FUNCSIG__ << " this:" << this << " m_array[0]:" << (int)m_array[0] << std::endl;
    }
    MyClass(const  MyClass& a)
    {
        memcpy(m_array, a.m_array, sizeof(m_array));
        std::cout << __FUNCSIG__ << " this:" << this << " from:" << &a << std::endl;
    }
    MyClass(MyClass&& a)
    {
        memcpy(m_array, a.m_array, sizeof(m_array));
        std::cout << __FUNCSIG__ << " this:" << this << " from:" << &a << std::endl;
    }
    ~MyClass()
    {
        std::cout << __FUNCSIG__ << " this:" << this << " m_array[0]:" << (int)m_array[0] << std::endl;
    }
    MyClass& operator=(const MyClass&) = default;
    void test() {}
};
//void* operator new(std::size_t sz)
//{
//    if (sz == 0)
//        ++sz; // avoid std::malloc(0) which may return nullptr on success
//
//    if (void* ptr = std::malloc(sz))
//    {
//        std::cout <<  __FUNCSIG__ << " ptr:" << ptr << " sz:" << sz << std::endl;
//        return ptr;
//    }
//
//    throw std::bad_alloc{}; // required by [new.delete.single]/3
//}
//void* operator new[](std::size_t count)
//{
//    if (count == 0)
//        ++count; // avoid std::malloc(0) which may return nullptr on success
//
//    if (void* ptr = std::malloc(count))
//    {
//        std::cout << __FUNCSIG__ << " ptr:" << ptr << " sz:" << count << std::endl;
//        return ptr;
//    }
//
//    throw std::bad_alloc{}; // required by [new.delete.single]/3
//}


int main()
{
    _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
    /*{
        long long total = 0;
        std::thread t([&](int s, int e) {
            for (int i = s; i <= e; ++i)
                total += i;
        }, 1, 10);
        t.join();

        std::cout << "��� : " << total << std::endl;
    }*/
    /*{
        std::promise<long long> p;
        std::thread t([&](int s, int e) {
            long long total = 0;
            for (int i = s; i <= e; ++i)
                total += i;

            p.set_value(total);
        }, 1, 10);
        t.detach();

        auto data = p.get_future();
        std::cout << "��� : " << data.get() << std::endl;
    }*/

    //{
    //    std::mutex m;
    //    std::condition_variable cv;
    //    long long total = 0;
    //    bool ready = false;
    //    std::thread t([&](int s, int e) {
    //        for (int i = s; i <= e; ++i)
    //            total += i;

    //        std::this_thread::sleep_for(std::chrono::milliseconds(1000));
    //        ready = true;
    //        cv.notify_one();
    //    }, 1, 10);
    //    t.detach();

    //    while (true)
    //    {   
    //        // �ֱ������� ������� �Դ��� üũ
    //        std::unique_lock<std::mutex> autoLock(m);
    //        auto status = cv.wait_for(autoLock, std::chrono::milliseconds(100), [&] {return ready; });
    //        if (!status)
    //        {
    //            std::cerr << '.';
    //        }
    //        else 
    //        {
    //            std::cout << std::endl;
    //            std::cout << "��� : " << total << std::endl;
    //            break;                
    //        }
    //    }
    //}
    //{
    //    std::promise<long long> p;
    //    std::thread t([&](int s, int e) {
    //        long long total = 0;
    //        for (int i = s; i <= e; ++i)
    //            total += i;

    //        std::this_thread::sleep_for(std::chrono::milliseconds(1000));
    //        p.set_value(total);
    //    }, 1, 10);
    //    t.detach();

    //    auto data = p.get_future();
    //    while (true)
    //    {
    //        // �ֱ������� ������� �Դ��� üũ
    //        auto status = data.wait_for(std::chrono::milliseconds(100));
    //        if (status == std::future_status::timeout)
    //        {
    //            std::cerr << '.';
    //        }
    //        else if (status == std::future_status::ready)
    //        {
    //            std::cout << std::endl;
    //            std::cout << "��� : " << data.get() << std::endl;
    //            break;
    //        }
    //    }
    //}
    /*{
        std::packaged_task<long long(int, int)> task([](int s, int e)->long long{
            long long total = 0;
            for (int i = s; i <= e; ++i)
                total += i;

            return total;
        });

        auto data = task.get_future();
        std::thread t(std::move(task), 1, 10);
        t.detach();

        std::cout << "��� : " << data.get() << std::endl;
    }*/
    {
        auto sumAsync = [](int s, int e) {
            auto startTime = std::chrono::system_clock::now();
            long long total = 0;
            for (int i = s; i <= e; ++i)
                total += i;

            auto endTime = std::chrono::system_clock::now();
            auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(endTime - startTime);
            std::stringstream ss;
            ss << "thread id:" << std::this_thread::get_id() << std::endl;
            ss << "sum(" << s << ", " << e << ") = " << total << std::endl;
            ss << "duration:" << duration.count() << std::endl;
            std::cout << ss.str();
            return total;
        };

        const int workers = 5;
        while (true)
        {
            int count;
            std::cin >> count;

            // ���� ���� �����ؼ� ��Ŀ���� ����
            std::array<std::future<long long>, workers> futures;
            auto divCount = count / workers;
            for (int i = 0; i < workers; ++i)
            {
                futures[i] = std::async(std::launch::async, sumAsync, i * divCount + 1, divCount * (i + 1));
            }

            while (true)
            {
                int finishedCount = 0;
                for (const auto& f : futures)
                {
                    if (std::future_status::ready == f.wait_for(std::chrono::milliseconds(0)))
                        finishedCount++;
                }

                if (finishedCount == workers)
                {
                    std::cout << "It's done." << std::endl;
                    break;
                }
            }
        }

    }
    int i;
    std::cin >> i;
}