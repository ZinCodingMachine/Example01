#include <iostream>
#include <thread>
#include <sstream>
#include <chrono>

int main()
{
    const auto a = 4;
    std::cout << &a << std::endl;

    std::cout << "Start..." << std::endl;
    std::atomic<int> total = 0;
    for (int i = 0; i < 10; ++i)
    {
        std::thread t1([&]() {
            // ���� ������ �ջ� ��� ������ �ϱ�
            // �� �Լ��ȿ��� �����ؾ� ��.
            auto startTime = std::chrono::system_clock::now();
            for (int i = 0; i < 10000000; ++i)
                ++total;

            auto endTime = std::chrono::system_clock::now();
            auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(endTime - startTime);
            std::stringstream ss;
            ss << "thread id:" << std::this_thread::get_id() << std::endl;
            ss << "duration:" << duration.count() << std::endl;
            std::cout << ss.str();
            });

        t1.detach();
    }

    int i;
    std::cin >> i;
}