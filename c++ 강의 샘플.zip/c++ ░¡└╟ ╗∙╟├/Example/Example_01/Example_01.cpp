﻿#include <iostream>
#include <thread>
#include <sstream>
#include <chrono>

int main()
{
    std::cout << "Start..." << std::endl;
    std::atomic<long long> total = 0;
    for (int i = 0; i < 10; ++i)
    {
        std::thread t1([&]() {            
            auto startTime = std::chrono::system_clock::now();
            // 더 빠르게 total에 더 할 수 있음
            for (int i = 1; i <= 10000000; ++i)
                total+=i;

            auto endTime = std::chrono::system_clock::now();
            auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(endTime - startTime);
            std::stringstream ss;
            ss << "thread id:" << std::this_thread::get_id() << std::endl;
            ss << "duration:" << duration.count() << std::endl;
            std::cout << ss.str();
        });

        t1.detach();
    }

    while (true)
    {
        int i;
        std::cin >> i;

        // 모두 계산 되었는지 확인
        std::cout << " total:" << total << std::endl;
    }
    
}