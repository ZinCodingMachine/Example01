#include <iostream>
#include "../Example_Dll/framework.h"

static int abc = 0;
int ss;
int main()
{
    char a[10];
    void* p = AllocMemory(10);
    int i;
    a[0] = 'a';
    std::cout << "&A:" << &a 
        << "&p:" << &p
        << "*&p:" << (*&p)
        << "Hello World Example!\n";
    std::cin >> i;
}