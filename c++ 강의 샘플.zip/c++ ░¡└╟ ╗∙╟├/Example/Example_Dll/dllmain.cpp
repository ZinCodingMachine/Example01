﻿// dllmain.cpp : DLL 애플리케이션의 진입점을 정의합니다.
#include "pch.h"
#include <memory>
#include <iostream>
int abc[0xfffffff];
LIBRARY_API void* APIENTRY AllocMemory(size_t size)
{
    char a[10];
    void* p;
    int i;
    a[0] = 'a';
    std::cout << "&A:" << &a
        << "&p:" << &p
        << "static abc:" << &abc
        << "Hello World Dll!\n";
    return malloc(size);
}

BOOL APIENTRY DllMain( HMODULE hModule,
                       DWORD  ul_reason_for_call,
                       LPVOID lpReserved
                     )
{
    switch (ul_reason_for_call)
    {
    case DLL_PROCESS_ATTACH:
    case DLL_THREAD_ATTACH:
    case DLL_THREAD_DETACH:
    case DLL_PROCESS_DETACH:
        break;
    }
    return TRUE;
}

